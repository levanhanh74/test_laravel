
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h5 class="text-center p-4">Add Department</h5>

        <div class="row m-5 ">
            <div class="col-6">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID_team</th>
                            <th scope="col">Name_team</th>
                            <th scope="col">ID_Department</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($listTeam)): ?>
                            <?php $__currentLoopData = $listTeam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($item->team_id); ?> </td>
                                    <td><?php echo e($item->team_name); ?></td>
                                    <td><?php echo e($item->department_id); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h4 class="text-danger">Data not isset</h4>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="col-6">
                <form method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">ID_team</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            placeholder="Enter ID_team..." name="team_id">
                        
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Name_team</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Name_team..."
                            name="team_name">
                    </div>
                    <div class="form-group">
                        <select name="department_id" class="form-control" id="exampleInputPassword1">
                            <option value="default">Chon di</option>
                            <?php if(isset($listDepartment)): ?>
                                <?php $__currentLoopData = $listDepartment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->department_id); ?>"><?php echo e($item->department_id); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <button type="submit" onclick="return comfirm('Ban co muon Add Team nay khong?')"
                        class="btn btn-primary">Add</button>
                    <a class="btn bg-primary text-white" href="<?php echo e(route('TeamList')); ?>">Cancel</a>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV_PHPLARAVEL\implement\resources\views/pageTeams/TeamAdd.blade.php ENDPATH**/ ?>