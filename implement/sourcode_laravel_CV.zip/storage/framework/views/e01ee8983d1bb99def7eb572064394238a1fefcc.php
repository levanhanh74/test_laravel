
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h5 class="text-center p-4">List Teams</h5>
        <?php if(session('mess')): ?>
            <h2 class="text-success"><?php echo e(session('mess')); ?></h2>
        <?php endif; ?>
        <div class="row m-5 ">
            <div class="col-6">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID_team</th>
                            <th scope="col">Name_team</th>
                            <th scope="col">ID_Department</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($listTeam)): ?>
                            <?php $__currentLoopData = $listTeam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('TeamList', ['id' => isset($item) ? $item->team_id : ''])); ?>">
                                            <?php echo e($item->team_id); ?></a>
                                    </td>
                                    <td><?php echo e($item->team_name); ?></td>
                                    <td><?php echo e($item->department_id); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h4 class="text-danger">Data not isset</h4>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="col-6">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">ID_team</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            value="<?php echo e(isset($getOneTeam) ? $getOneTeam->team_id : ''); ?>" placeholder="Enter email"
                            name="team_id">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Name_team</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Password"
                            value="<?php echo e(isset($getOneTeam) ? $getOneTeam->team_name : ''); ?>" name="team_name">
                    </div>
                    <div class="form-group">
                        <select name="department_id" class="form-control" id="exampleInputPassword1">
                            <?php if(isset($listDepartment)): ?>
                                <option value="<?php echo e(isset($getOneTeam) ? $getOneTeam->department_id : ''); ?>">
                                    <?php echo e(isset($getOneTeam) ? $getOneTeam->department_id : ''); ?></option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <a href="<?php echo e(route('CreateTeam')); ?>" class="btn bg-primary text-white" href="">Add</a>
                    <a href="<?php echo e(route('editTeam', ['id' => isset($getOneTeam) ? $getOneTeam->team_id : ''])); ?>"
                        class="btn bg-primary text-white" href="">Edit</a>
                    <button type="submit" onclick="return confirm('Ban co muon Delete Team nay khong?')" class="btn btn-primary">Delete</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV_PHPLARAVEL\implement\resources\views/pageTeams/Teams.blade.php ENDPATH**/ ?>