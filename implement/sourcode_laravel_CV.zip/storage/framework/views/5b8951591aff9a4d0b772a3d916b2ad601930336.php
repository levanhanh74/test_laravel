
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h5 class="text-center p-4">Edit Department</h5>

        <div class="row m-5 ">
            <div class="col-6">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID_team</th>
                            <th scope="col">Name_team</th>
                            <th scope="col">ID_Department</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($listTeam)): ?>
                            <?php $__currentLoopData = $listTeam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($item->team_id); ?> </td>
                                    <td><?php echo e($item->team_name); ?></td>
                                    <td><?php echo e($item->department_id); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h4 class="text-danger">Data not isset</h4>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="col-6">
                <form method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">ID_team</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            value="<?php echo e(isset($getOneTeam) ? $getOneTeam->team_id : ''); ?>" placeholder="Enter ID_team..."
                            name="team_id">
                        <?php $__errorArgs = ['team_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Name_team</label>
                        <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Name_team..."
                            value="<?php echo e(isset($getOneTeam) ? $getOneTeam->team_name : ''); ?>" name="team_name">
                        <?php $__errorArgs = ['team_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <select name="department_id" class="form-control" id="exampleInputPassword1">
                            <option value="<?php echo e(isset($getOneTeam) ? $getOneTeam->department_id : ''); ?>">
                                <?php echo e(isset($getOneTeam) ? $getOneTeam->department_id : ''); ?>

                            </option>
                            <?php if(isset($listDepartment)): ?>
                                <?php $__currentLoopData = $listDepartment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->department_id); ?>"><?php echo e($item->department_id); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <button type="submit" onclick="return confirm('Ban co muon Update Team nay khong?')"
                        class="btn btn-primary">Update</button>
                    <a class="btn bg-primary text-white" href="<?php echo e(route('TeamList')); ?>">Cancel</a>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV_PHPLARAVEL\implement\resources\views/pageTeams/TeamEdit.blade.php ENDPATH**/ ?>