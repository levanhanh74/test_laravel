
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h5 class="text-center p-4">List Department</h5>
        <?php if(session('mess')): ?>
            <h2 class="text-success"><?php echo e(session('mess')); ?></h2>
        <?php endif; ?>
        <div class="row m-5 ">
            <div class="col-6">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID_team</th>
                            <th scope="col">Name_team</th>
                            <th scope="col">Descriptions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($listDepartment)): ?>
                            <?php $__currentLoopData = $listDepartment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('getDepartment', ['id' => $item->department_id])); ?>">
                                            <?php echo e($item->department_id); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($item->department_name); ?></td>
                                    <td><?php echo e($item->descriptions); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h3 class="text-danger">Dữ liệu không tồn tại</h3>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="col-6">
                
                <form method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">DepartmentId</label>
                        <input type="text" class="form-control" id="exampleInputEmail1"
                            value="<?php echo e(isset($oneDepartment) ? $oneDepartment->department_id : ''); ?>"
                            aria-describedby="emailHelp" placeholder="Enter DepartmentId..." name="department_id">
                        <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">DepartmentName</label>
                        <input type="text" class="form-control" id="exampleInputPassword1"
                            value="<?php echo e(isset($oneDepartment) ? $oneDepartment->department_name : ''); ?>"
                            placeholder="Enter DepartmentName..." name="department_name">
                        <?php $__errorArgs = ['department_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Descriptions</label>
                        <input type="text" class="form-control" id="exampleInputPassword1"
                            value="<?php echo e(isset($oneDepartment) ? $oneDepartment->descriptions : ''); ?>"
                            placeholder="Enter Descriptions..." name="descriptions">
                        <?php $__errorArgs = ['descriptions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <a href="<?php echo e(route('createDepartment')); ?>" class="btn btn-primary">Add</a>
                    <a href="<?php echo e(route('deleteDepartment', ['id' => isset($oneDepartment) ? $oneDepartment->department_id : ''])); ?>" 
                        class="btn btn-primary">Delete</a>
                    <a href="<?php echo e(route('editDepartment', ['id' => isset($oneDepartment) ? $oneDepartment->department_id : ''])); ?>"
                        class="btn btn-primary">Edit</a>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CV_PHPLARAVEL\implement\resources\views/Department.blade.php ENDPATH**/ ?>